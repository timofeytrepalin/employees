import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import Components from 'unplugin-vue-components/vite'
import vueDevTools from 'vite-plugin-vue-devtools'
import { mockDevServerPlugin } from 'vite-plugin-mock-dev-server'
import svgLoader from 'vite-svg-loader';
import dynamicImport from 'vite-plugin-dynamic-import';
import VueI18nPlugin from '@intlify/unplugin-vue-i18n/vite'
import path from 'node:path'
// import eslint from 'vite-plugin-eslint'

// https://vite.dev/config/
export default defineConfig({
  resolve: {
    alias: {
      '@': '/src',
      // '@': fileURLToPath(new URL('./src', import.meta.url)),
    }
  },
  plugins: [
    vue(),
    vueDevTools(),
    svgLoader(),
    dynamicImport(),
    VueI18nPlugin({
      include: [path.resolve(__dirname, './src/i18n/lang/**')]
    }),
    
    mockDevServerPlugin({
      // prefix: ['/api'], // Префикс для перехвата
      log: 'debug', // Логи для отладки
    }),
    // eslint({
    //   include: ['src/**/*.ts', 'src/**/*.vue', 'src/*.ts', 'src/*.vue']
    // }),
    Components({
      dts: true, // генерация типов
      dirs: ['src/components'] // директории для автоимпорта
    })
  ],
  css: {
    preprocessorOptions: {
      scss: {
        additionalData: `
          @use "@/styles/variables.scss" as *;
          @use "@/styles/mixins.scss" as *;
        `,
      },
    },
  },
  server: {
    cors: true, // CORS для локальных ответов
    proxy: {
       '^/api': {
        target: 'http://example.com',
        // changeOrigin: true, // Меняем origin на локальный
      },
    }
}})
