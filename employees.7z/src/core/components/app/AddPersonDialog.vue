<template>
  <base-modal :isOpen :title="t('addPersonForm.email')" @close="emit('close')">
    <div class="employee-form">
      <!-- <h3 class="employee-form__title">Add new employee</h3> -->

      <div class="employee-form__grid">
        <div class="employee-form__field">
          <p class="employee-form__label">{{ t('addPersonForm.title') }}</p>
          <CustomInput v-model="form.name" class="employee-form__input" required />
        </div>

        <div class="employee-form__field">
          <p class="employee-form__label">{{ t('addPersonForm.email') }}</p>
          <CustomInput v-model="form.email" class="employee-form__input" :validationFunction="employeeValidation.validateEmail" type="email" />
        </div>

        <!-- Остальные поля по аналогии -->
        <div class="employee-form__field">
          <p class="employee-form__label">{{ t('addPersonForm.avatar') }}</p>
          <CustomInput v-model="form.avatar" class="employee-form__input" />
        </div>

        <div class="employee-form__field">
          <p class="employee-form__label">{{ t('addPersonForm.employeeCode') }}</p>
          <CustomInput v-model="form.employeeCode" class="employee-form__input" required/>
        </div>

        <div class="employee-form__field">
          <p class="employee-form__label">{{ t('addPersonForm.designation') }}</p>
          <CustomInput v-model="form.designation" class="employee-form__input" required/>
        </div>

        <div class="employee-form__field">
          <p class="employee-form__label">{{ t('addPersonForm.phone') }}</p>
          <CustomInput v-model="form.phone" class="employee-form__input" :validationFunction="employeeValidation.validatePhone" type="text" />
        </div>

        <div class="employee-form__field">
          <p class="employee-form__label">{{ t('addPersonForm.joiningDate') }}</p>
          <CustomInput v-model="form.joiningDate" class="employee-form__input" :validationFunction="employeeValidation.validateDate" type="date" />
        </div>
      </div>

      <div class="employee-form__actions">
        <CustomButton class="employee-form__button" @click="handleSave"> {{ t('addPersonForm.save') }} </CustomButton>
      </div>
    </div>
  </base-modal>
</template>

<script lang="ts" setup>
import { reactive, toRaw } from 'vue'
import BaseModal from '@/core/components/ui/Dialog/NativeModal.vue'
import CustomInput from '@/core/components/ui/Input/CustomInput.vue'
import CustomButton from '@/core/components/ui/Button/CustomButton.vue'
import { useI18n } from 'vue-i18n'

import { useEmployeeValidation } from '@/core/composables/useEmployeeValidation'

const employeeValidation = useEmployeeValidation();
const { t } = useI18n()

interface Props {
  isOpen: boolean
}

withDefaults(defineProps<Props>(), {
  isOpen: false,
})

// const store = useStore()
const emit = defineEmits(['close', 'submit'])


const form = reactive({
  name: '',
  email: '',
  avatar: '',
  employeeCode: '',
  designation: '',
  phone: '',
  joiningDate: '',
})

const handleSave = () => {
  emit('submit', toRaw(form))
}
</script>

<style lang="scss">
.employee-form {
  width: 600px;
  background: var(--color-base-background-secondary); // Тёмный серый фон
  padding: var(--basic-spacing-medium); // 24px
  border-radius: var(--border-radius-medium); // 8px
  box-shadow: var(--shadow-dark); // Мягкая тень

  &__grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: var(--basic-spacing-big); // 48px
    margin-bottom: var(--basic-spacing); // 16px
  }

  &__field {
    display: flex;
    width: 100%;
    flex-direction: column;
  }

  &__label {
    margin-bottom: var(--basic-spacing-small); // 8px
    font-family: var(--font-family-default);
    font-size: var(--font-size-small); // 12px
    font-weight: var(--font-weight-medium); // 500
    line-height: var(--line-height-base); // 1.5
    color: var(--color-base-content-secondary); // Серый текст
    letter-spacing: var(--letter-spacing-small); // 0.04em
  }

  &__actions {
    display: flex;
    justify-content: flex-end;
  }

  // &__button {
  //   padding: var(--basic-spacing-small) var(--basic-spacing); // 8px 16px
  //   background: var(--color-status-success); // Мятный зелёный
  //   color: var(--color-base-on-primary); // Белый текст
  //   border: 1px solid var(--color-base-border-accent); // Акцентная граница
  //   border-radius: var(--border-radius); // 4px
  //   font-family: var(--font-family-system);
  //   font-size: var(--font-size-base); // 14px
  //   font-weight: var(--font-weight-medium); // 500
  //   line-height: var(--line-height-base); // 1.5
  //   cursor: pointer;
  //   transition: background var(--transition-ease) 0.2s;

  //   &:hover {
  //     background: linear-gradient(
  //       98.19deg,
  //       rgba(40, 167, 69, 1) -4.08%,
  //       rgba(9, 255, 144, 1) 309.87%
  //     ); // Яркий мятный градиент
  //     border-color: var(--color-status-success); // Мятная граница
  //   }
  // }
}
</style>