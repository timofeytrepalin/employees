<template>
  <base-modal :isOpen :title="props.title" @close="emit('close')">
    <div class="confirm-dialog-form">
      <slot />
      <div class="confirm-dialog-form__actions">
        <CustomButton class="confirm-dialog-form__button" @click="emit('close')">{{ t('cancel') }}</CustomButton>
        <CustomButton class="confirm-dialog-form__button" @click="handleConfirm">{{ props.confirmTitle }}</CustomButton>
      </div>
    </div>
  </base-modal>
</template>

<script lang="ts" setup>
import BaseModal from '@/core/components/ui/Dialog/NativeModal.vue'
import CustomButton from '@/core/components/ui/Button/CustomButton.vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

interface Props {
  isOpen: boolean
  confirmTitle?: string
  title?: string
}

const props = withDefaults(defineProps<Props>(), {
  isOpen: false,
  confirmTitle: 'Confirm',
  title: 'Confirm'
})

const emit = defineEmits(['close', 'confirm'])

const handleConfirm = () => {
  emit('confirm')
}
</script>

<style lang="scss">
.confirm-dialog-form {
  width: 600px;
  background: var(--color-base-background-secondary); // Тёмный серый фон
  padding: var(--basic-spacing); // 16px
  border-radius: var(--border-radius-medium); // 8px
  box-shadow: var(--shadow-dark); // Мягкая тень

  &__actions {
    display: flex;
    justify-content: center;
    gap: var(--basic-spacing-big); // 48px
    width: 100%;
    margin-top: var(--basic-spacing); // 16px
  }

  &__button {
    padding: var(--basic-spacing-small) var(--basic-spacing); // 8px 16px
    background: var(--color-base-background-utility); // Утилитарный тёмный фон
    color: var(--color-base-on-primary); // Белый текст
    border: 1px solid var(--color-base-border-primary); // Тонкая белая граница
    border-radius: var(--border-radius); // 4px
    font-family: var(--font-family-system);
    font-size: var(--font-size-base); // 14px
    font-weight: var(--font-weight-medium); // 500
    line-height: var(--line-height-base); // 1.5
    cursor: pointer;
    transition: background var(--transition-ease) 0.2s, border-color var(--transition-ease) 0.2s;

    &:hover {
      background: var(--color-base-background-quaternary); // Светлее серый
      border-color: var(--color-base-border-accent); // Акцентная граница
    }

    &:last-child {
      background: var(--color-status-success); // Мятный зелёный для Confirm
      border-color: var(--color-status-success); // Мятная граница

      &:hover {
        background: linear-gradient(
          98.19deg,
          rgba(40, 167, 69, 1) -4.08%,
          rgba(9, 255, 144, 1) 309.87%
        ); // Яркий мятный градиент
      }
    }
  }
}
</style>